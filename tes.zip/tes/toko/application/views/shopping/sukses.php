<h2>Proses Order sukses</h2>
<div class="kotak2">
<p>Terima kasih sudah berbelanja di TUKUTUH.id. Order anda sudah masuk ke database kami, 1-2 barang akan sampai di tempat anda.<br>
Semoga anda puas kami pun puas.</p>
</div>