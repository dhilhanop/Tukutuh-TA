<h3>Cara Bayar</h3>
<h3>1. Pilihlah Barang yang ingin dibeli lalu tekan tombol beli</h3>
<h3>2. Kemudian setelah tekan tombol beli anda masuk kedalam menu keranjang belanja</h3>
<h3>3. Di menu keranjang ada sebuah daftar belanjaan anda. Anda akan diberi 3 opsi yaitu kosongkan chart, update chart, dan check out</h3>
<h3>4. Jika ingin menambah barang belanjaan anda bisa pilih update, kosongkan chart hanya untuk menosongi keranjang anda. Namu untuk membayar anda pilih check out</h3>
<h3>5. Anda akan masuk ke dalam konfirmasi check out, disitu anda akan dilihatkan total belanjaan dan mengisi identitas tersebut</h3>
<h3>6. Setelah mengisi identitas anda langsung tekan tombol next order, jika sudah anda akan masuk ke proses order.</h3>


